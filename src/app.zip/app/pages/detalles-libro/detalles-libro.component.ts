import { Component } from '@angular/core';

@Component({
  selector: 'app-detalles-libro',
  templateUrl: './detalles-libro.component.html',
  styleUrls: ['./detalles-libro.component.scss']
})
export class DetallesLibroComponent {

}
